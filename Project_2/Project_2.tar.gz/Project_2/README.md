# CMSC423_rna_quant
Run command:

    $ python3 squant.py --in INPUT_FILE --out OUTPUT_FILE
    or with optional EQC flag
    $ python3 squant.py --in INPUT_FILE --out OUTPUT_FILE --eqc

Result will be stored in OUTPUT_FILE